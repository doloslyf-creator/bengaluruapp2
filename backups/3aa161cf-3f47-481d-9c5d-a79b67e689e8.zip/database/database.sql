--
-- PostgreSQL database dump
--

-- Dumped from database version 16.9
-- Dumped by pg_dump version 16.9

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: api_keys_settings; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.api_keys_settings (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    razorpay_key_id text,
    razorpay_key_secret text,
    razorpay_webhook_secret text,
    razorpay_test_mode boolean DEFAULT true,
    google_maps_api_key text,
    google_analytics_id text,
    twilio_account_sid text,
    twilio_auth_token text,
    twilio_phone_number text,
    whatsapp_business_api_key text,
    whatsapp_phone_number_id text,
    sendgrid_api_key text,
    sendgrid_from_email text,
    surepass_api_key text,
    signzy_api_key text,
    magicbricks_api_key text,
    acres_99_api_key text,
    last_updated timestamp without time zone DEFAULT now(),
    updated_by text DEFAULT 'admin'::text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.api_keys_settings OWNER TO neondb_owner;

--
-- Name: app_settings; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.app_settings (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    business_name text DEFAULT 'OwnItRight – Curated Property Advisors'::text,
    logo_url text,
    favicon_url text,
    contact_email text DEFAULT 'contact@ownitright.com'::text,
    phone_number text DEFAULT '+91 98765 43210'::text,
    whatsapp_number text DEFAULT '+91 98765 43210'::text,
    office_address text DEFAULT 'Bengaluru, Karnataka, India'::text,
    default_currency character varying DEFAULT 'INR'::character varying,
    currency_symbol text DEFAULT '₹'::text,
    timezone text DEFAULT 'Asia/Kolkata'::text,
    date_format character varying DEFAULT 'DD/MM/YYYY'::character varying,
    maintenance_mode boolean DEFAULT false,
    maintenance_message text DEFAULT 'We are currently performing maintenance. Please check back later.'::text,
    primary_color text DEFAULT '#2563eb'::text,
    secondary_color text DEFAULT '#64748b'::text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.app_settings OWNER TO neondb_owner;

--
-- Name: blog_posts; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.blog_posts (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    title text NOT NULL,
    slug text NOT NULL,
    excerpt text,
    content text NOT NULL,
    meta_title text,
    meta_description text,
    tags json DEFAULT '[]'::json NOT NULL,
    category character varying NOT NULL,
    status character varying DEFAULT 'draft'::character varying NOT NULL,
    published_at timestamp without time zone,
    featured_image text,
    images json DEFAULT '[]'::json NOT NULL,
    author text NOT NULL,
    reading_time integer DEFAULT 5,
    views integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.blog_posts OWNER TO neondb_owner;

--
-- Name: bookings; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.bookings (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    booking_id character varying NOT NULL,
    property_id character varying,
    property_name text NOT NULL,
    booking_type character varying NOT NULL,
    name text NOT NULL,
    phone text NOT NULL,
    email text NOT NULL,
    preferred_date text,
    preferred_time text,
    visit_type character varying,
    number_of_visitors text,
    consultation_type character varying,
    preferred_contact_time text,
    urgency character varying,
    questions text,
    special_requests text,
    status character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.bookings OWNER TO neondb_owner;

--
-- Name: civil_mep_reports; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.civil_mep_reports (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    property_id character varying NOT NULL,
    report_type character varying DEFAULT 'combined'::character varying NOT NULL,
    report_version text DEFAULT '1.0'::text,
    generated_by text,
    report_date timestamp without time zone DEFAULT now(),
    structural_analysis json,
    material_breakdown json,
    cost_breakdown json,
    quality_assessment json,
    mep_systems json,
    compliance_checklist json,
    snag_report json,
    executive_summary text,
    overall_score numeric(3,1) DEFAULT 0.0,
    investment_recommendation character varying,
    estimated_maintenance_cost numeric(10,2),
    report_pdf_url text,
    supporting_documents json DEFAULT '[]'::json,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.civil_mep_reports OWNER TO neondb_owner;

--
-- Name: customer_notes; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.customer_notes (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    customer_id character varying NOT NULL,
    content text NOT NULL,
    created_by text DEFAULT 'admin'::text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.customer_notes OWNER TO neondb_owner;

--
-- Name: lead_activities; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.lead_activities (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    lead_id character varying NOT NULL,
    activity_type character varying NOT NULL,
    subject text NOT NULL,
    description text,
    outcome character varying,
    next_action text,
    scheduled_at timestamp without time zone,
    completed_at timestamp without time zone,
    performed_by text NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.lead_activities OWNER TO neondb_owner;

--
-- Name: lead_notes; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.lead_notes (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    lead_id character varying NOT NULL,
    note text NOT NULL,
    note_type character varying DEFAULT 'general'::character varying,
    is_private boolean DEFAULT false,
    created_by text NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.lead_notes OWNER TO neondb_owner;

--
-- Name: leads; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.leads (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    lead_id character varying NOT NULL,
    source character varying NOT NULL,
    lead_type character varying DEFAULT 'warm'::character varying NOT NULL,
    priority character varying DEFAULT 'medium'::character varying NOT NULL,
    customer_name text NOT NULL,
    phone text NOT NULL,
    email text NOT NULL,
    property_id character varying,
    property_name text NOT NULL,
    interested_configuration text,
    budget_range text,
    lead_details json DEFAULT '{}'::json NOT NULL,
    lead_score integer DEFAULT 0,
    qualification_notes text,
    status character varying DEFAULT 'new'::character varying NOT NULL,
    assigned_to text,
    last_contact_date timestamp without time zone,
    next_follow_up_date timestamp without time zone,
    communication_preference character varying DEFAULT 'phone'::character varying,
    expected_close_date timestamp without time zone,
    deal_value integer,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.leads OWNER TO neondb_owner;

--
-- Name: notification_preferences; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.notification_preferences (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    user_type character varying DEFAULT 'user'::character varying NOT NULL,
    email_notifications boolean DEFAULT true NOT NULL,
    push_notifications boolean DEFAULT true NOT NULL,
    sms_notifications boolean DEFAULT false NOT NULL,
    property_updates boolean DEFAULT true NOT NULL,
    report_notifications boolean DEFAULT true NOT NULL,
    booking_notifications boolean DEFAULT true NOT NULL,
    payment_notifications boolean DEFAULT true NOT NULL,
    lead_notifications boolean DEFAULT true NOT NULL,
    system_notifications boolean DEFAULT true NOT NULL,
    promotional_notifications boolean DEFAULT false NOT NULL,
    digest_frequency character varying DEFAULT 'immediate'::character varying NOT NULL,
    quiet_hours_start character varying DEFAULT '22:00'::character varying,
    quiet_hours_end character varying DEFAULT '08:00'::character varying,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.notification_preferences OWNER TO neondb_owner;

--
-- Name: notification_templates; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.notification_templates (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    template_key character varying NOT NULL,
    name character varying NOT NULL,
    description text,
    title_template character varying NOT NULL,
    message_template text NOT NULL,
    email_subject_template character varying,
    email_body_template text,
    type character varying DEFAULT 'info'::character varying NOT NULL,
    category character varying DEFAULT 'system'::character varying NOT NULL,
    priority character varying DEFAULT 'medium'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    requires_email boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.notification_templates OWNER TO neondb_owner;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.notifications (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying,
    user_type character varying DEFAULT 'user'::character varying NOT NULL,
    title character varying NOT NULL,
    message text NOT NULL,
    type character varying DEFAULT 'info'::character varying NOT NULL,
    category character varying DEFAULT 'system'::character varying NOT NULL,
    priority character varying DEFAULT 'medium'::character varying NOT NULL,
    action_url character varying,
    action_text character varying,
    is_read boolean DEFAULT false NOT NULL,
    is_archived boolean DEFAULT false NOT NULL,
    read_at timestamp without time zone,
    email_sent boolean DEFAULT false NOT NULL,
    email_sent_at timestamp without time zone,
    related_entity_type character varying,
    related_entity_id character varying,
    metadata json DEFAULT '{}'::json,
    expires_at timestamp without time zone,
    scheduled_for timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.notifications OWNER TO neondb_owner;

--
-- Name: properties; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.properties (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    type character varying NOT NULL,
    developer text NOT NULL,
    status character varying NOT NULL,
    area text NOT NULL,
    zone character varying NOT NULL,
    address text NOT NULL,
    possession_date text,
    rera_number text,
    rera_approved boolean DEFAULT false,
    infrastructure_verdict text,
    zoning_info text,
    tags json DEFAULT '[]'::json NOT NULL,
    images json DEFAULT '[]'::json NOT NULL,
    videos json DEFAULT '[]'::json NOT NULL,
    youtube_video_url text,
    property_score_id character varying,
    location_score integer DEFAULT 0,
    amenities_score integer DEFAULT 0,
    value_score integer DEFAULT 0,
    overall_score numeric(3,1) DEFAULT 0.0,
    area_avg_price_min integer,
    area_avg_price_max integer,
    city_avg_price_min integer,
    city_avg_price_max integer,
    price_comparison text,
    title_clearance_status text,
    ownership_type text,
    legal_opinion_provided_by text,
    title_flow_summary text,
    encumbrance_status text,
    ec_extract_link text,
    mutation_status text,
    conversion_certificate boolean DEFAULT false,
    rera_registered boolean DEFAULT false,
    rera_id text,
    rera_link text,
    litigation_status text,
    approving_authorities json DEFAULT '[]'::json,
    layout_sanction_copy_link text,
    legal_comments text,
    legal_verdict_badge text,
    has_civil_mep_report boolean DEFAULT false,
    civil_mep_report_price numeric(10,2) DEFAULT 2999.00,
    civil_mep_report_status character varying DEFAULT 'draft'::character varying,
    has_valuation_report boolean DEFAULT false,
    valuation_report_price numeric(10,2) DEFAULT 15000.00,
    valuation_report_status character varying DEFAULT 'draft'::character varying,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.properties OWNER TO neondb_owner;

--
-- Name: property_configurations; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.property_configurations (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    property_id character varying NOT NULL,
    configuration text NOT NULL,
    price_per_sqft numeric(10,2) NOT NULL,
    built_up_area integer NOT NULL,
    plot_size integer,
    availability_status character varying NOT NULL,
    total_units integer,
    available_units integer,
    price integer NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.property_configurations OWNER TO neondb_owner;

--
-- Name: property_scores; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.property_scores (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    property_id character varying NOT NULL,
    scoring_version text DEFAULT '1.0'::text,
    scored_by text,
    scoring_date timestamp without time zone DEFAULT now(),
    last_updated timestamp without time zone DEFAULT now(),
    transport_connectivity integer DEFAULT 0,
    transport_notes text,
    infrastructure_development integer DEFAULT 0,
    infrastructure_notes text,
    social_infrastructure integer DEFAULT 0,
    social_notes text,
    employment_hubs integer DEFAULT 0,
    employment_notes text,
    basic_amenities integer DEFAULT 0,
    basic_amenities_notes text,
    lifestyle_amenities integer DEFAULT 0,
    lifestyle_amenities_notes text,
    modern_features integer DEFAULT 0,
    modern_features_notes text,
    rera_compliance integer DEFAULT 0,
    rera_compliance_notes text,
    title_clarity integer DEFAULT 0,
    title_clarity_notes text,
    approvals integer DEFAULT 0,
    approvals_notes text,
    price_competitiveness integer DEFAULT 0,
    price_competitiveness_notes text,
    appreciation_potential integer DEFAULT 0,
    appreciation_potential_notes text,
    rental_yield integer DEFAULT 0,
    rental_yield_notes text,
    track_record integer DEFAULT 0,
    track_record_notes text,
    financial_stability integer DEFAULT 0,
    financial_stability_notes text,
    customer_satisfaction integer DEFAULT 0,
    customer_satisfaction_notes text,
    structural_quality integer DEFAULT 0,
    structural_quality_notes text,
    finishing_standards integer DEFAULT 0,
    finishing_standards_notes text,
    maintenance_standards integer DEFAULT 0,
    maintenance_standards_notes text,
    location_score_total integer DEFAULT 0,
    amenities_score_total integer DEFAULT 0,
    legal_score_total integer DEFAULT 0,
    value_score_total integer DEFAULT 0,
    developer_score_total integer DEFAULT 0,
    construction_score_total integer DEFAULT 0,
    overall_score_total integer DEFAULT 0,
    overall_grade character varying,
    key_strengths json DEFAULT '[]'::json,
    areas_of_concern json DEFAULT '[]'::json,
    recommendation_summary text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.property_scores OWNER TO neondb_owner;

--
-- Name: property_valuation_reports; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.property_valuation_reports (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    property_id character varying NOT NULL,
    report_version text DEFAULT '1.0'::text,
    generated_by text,
    report_date timestamp without time zone DEFAULT now(),
    market_analysis json,
    property_assessment json,
    cost_breakdown json,
    financial_analysis json,
    investment_recommendation character varying,
    risk_assessment json,
    executive_summary text,
    overall_score numeric(3,1) DEFAULT 0.0,
    key_highlights json DEFAULT '[]'::json,
    report_pdf_url text,
    supporting_documents json DEFAULT '[]'::json,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.property_valuation_reports OWNER TO neondb_owner;

--
-- Name: report_payments; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.report_payments (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    report_id character varying,
    report_type character varying DEFAULT 'civil-mep'::character varying NOT NULL,
    property_id character varying,
    customer_name text NOT NULL,
    customer_email text NOT NULL,
    customer_phone text,
    amount numeric(10,2) NOT NULL,
    currency text DEFAULT 'INR'::text,
    payment_method character varying NOT NULL,
    payment_status character varying DEFAULT 'pending'::character varying,
    stripe_payment_intent_id text,
    stripe_customer_id text,
    pay_later_due_date timestamp without time zone,
    pay_later_reminders_sent integer DEFAULT 0,
    access_granted_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.report_payments OWNER TO neondb_owner;

--
-- Name: rera_data; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.rera_data (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    rera_id text NOT NULL,
    property_id character varying,
    project_name text NOT NULL,
    promoter_name text NOT NULL,
    location text NOT NULL,
    district text NOT NULL,
    state text DEFAULT 'Karnataka'::text,
    project_type character varying DEFAULT 'residential'::character varying,
    total_units integer,
    project_area text,
    built_up_area text,
    registration_date text,
    approval_date text,
    completion_date text,
    registration_valid_till text,
    project_status character varying DEFAULT 'under-construction'::character varying,
    compliance_status character varying DEFAULT 'active'::character varying,
    project_cost text,
    amount_collected text,
    percentage_collected real,
    website text,
    contact_phone text,
    contact_email text,
    promoter_address text,
    rera_portal_link text,
    verification_status character varying DEFAULT 'pending'::character varying,
    last_verified_at timestamp without time zone,
    last_sync_at timestamp without time zone,
    sync_failure_reason text,
    raw_api_response json,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.rera_data OWNER TO neondb_owner;

--
-- Name: team_members; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.team_members (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    name character varying NOT NULL,
    email character varying NOT NULL,
    phone character varying,
    role character varying DEFAULT 'agent'::character varying NOT NULL,
    department character varying DEFAULT 'sales'::character varying NOT NULL,
    permissions json DEFAULT '[]'::json,
    status character varying DEFAULT 'active'::character varying NOT NULL,
    join_date timestamp without time zone DEFAULT now(),
    last_active timestamp without time zone,
    profile_image character varying,
    bio character varying,
    specializations json DEFAULT '[]'::json,
    performance_score integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.team_members OWNER TO neondb_owner;

--
-- Name: users; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.users (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    email text NOT NULL,
    name text NOT NULL,
    role character varying DEFAULT 'user'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.users OWNER TO neondb_owner;

--
-- Name: valuation_requests; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.valuation_requests (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    property_type text NOT NULL,
    location text NOT NULL,
    area integer NOT NULL,
    age integer NOT NULL,
    bedrooms text NOT NULL,
    amenities json DEFAULT '[]'::json,
    additional_info text,
    contact_name text NOT NULL,
    contact_phone text NOT NULL,
    contact_email text NOT NULL,
    status character varying DEFAULT 'pending'::character varying,
    request_source text DEFAULT 'website'::text,
    estimated_value numeric(12,2),
    value_range json,
    confidence_level character varying,
    report_generated boolean DEFAULT false,
    report_url text,
    report_notes text,
    assigned_to text,
    processed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.valuation_requests OWNER TO neondb_owner;

--
-- Data for Name: api_keys_settings; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.api_keys_settings (id, razorpay_key_id, razorpay_key_secret, razorpay_webhook_secret, razorpay_test_mode, google_maps_api_key, google_analytics_id, twilio_account_sid, twilio_auth_token, twilio_phone_number, whatsapp_business_api_key, whatsapp_phone_number_id, sendgrid_api_key, sendgrid_from_email, surepass_api_key, signzy_api_key, magicbricks_api_key, acres_99_api_key, last_updated, updated_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: app_settings; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.app_settings (id, business_name, logo_url, favicon_url, contact_email, phone_number, whatsapp_number, office_address, default_currency, currency_symbol, timezone, date_format, maintenance_mode, maintenance_message, primary_color, secondary_color, created_at, updated_at) FROM stdin;
00ef2c9b-933d-435e-b20e-ece29ca281bd	OwnItRight – Curated Property Advisors	\N	\N	contact@ownitright.com	+91 98765 43210	+91 98765 43210	Bengaluru, Karnataka, India	INR	₹	Asia/Kolkata	DD/MM/YYYY	f	We are currently performing maintenance. Please check back later.	#2563eb	#64748b	2025-08-03 19:26:24.085646	2025-08-03 19:26:24.085646
\.


--
-- Data for Name: blog_posts; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.blog_posts (id, title, slug, excerpt, content, meta_title, meta_description, tags, category, status, published_at, featured_image, images, author, reading_time, views, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: bookings; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.bookings (id, booking_id, property_id, property_name, booking_type, name, phone, email, preferred_date, preferred_time, visit_type, number_of_visitors, consultation_type, preferred_contact_time, urgency, questions, special_requests, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: civil_mep_reports; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.civil_mep_reports (id, property_id, report_type, report_version, generated_by, report_date, structural_analysis, material_breakdown, cost_breakdown, quality_assessment, mep_systems, compliance_checklist, snag_report, executive_summary, overall_score, investment_recommendation, estimated_maintenance_cost, report_pdf_url, supporting_documents, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: customer_notes; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.customer_notes (id, customer_id, content, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: lead_activities; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.lead_activities (id, lead_id, activity_type, subject, description, outcome, next_action, scheduled_at, completed_at, performed_by, created_at) FROM stdin;
\.


--
-- Data for Name: lead_notes; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.lead_notes (id, lead_id, note, note_type, is_private, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: leads; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.leads (id, lead_id, source, lead_type, priority, customer_name, phone, email, property_id, property_name, interested_configuration, budget_range, lead_details, lead_score, qualification_notes, status, assigned_to, last_contact_date, next_follow_up_date, communication_preference, expected_close_date, deal_value, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notification_preferences; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.notification_preferences (id, user_id, user_type, email_notifications, push_notifications, sms_notifications, property_updates, report_notifications, booking_notifications, payment_notifications, lead_notifications, system_notifications, promotional_notifications, digest_frequency, quiet_hours_start, quiet_hours_end, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notification_templates; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.notification_templates (id, template_key, name, description, title_template, message_template, email_subject_template, email_body_template, type, category, priority, is_active, requires_email, created_at, updated_at) FROM stdin;
41a3ec3b-a22d-4264-b1b5-a9b468df1b7e	REPORT_READY	Report Ready	Notification when a property report is ready for download	{{reportType}} Report Ready	Your {{reportType}} report for property {{propertyName}} is now ready for download.	OwnItRight: Your {{reportType}} Report is Ready	<h2>Your {{reportType}} Report is Ready!</h2><p>Dear Customer,</p><p>Your {{reportType}} report for the property {{propertyName}} has been completed and is now ready for download.</p><p>You can access your report through your dashboard or by clicking the link below.</p><p>Thank you for choosing OwnItRight for your property advisory needs.</p>	report	report	medium	t	t	2025-08-03 19:30:37.371866	2025-08-03 19:30:37.371866
94f7db6d-1928-407a-85e8-5402e1759a5b	BOOKING_CONFIRMED	Booking Confirmed	Notification when a site visit booking is confirmed	Site Visit Booking Confirmed	Your site visit for {{propertyName}} has been confirmed for {{visitDate}}.	OwnItRight: Site Visit Confirmed - {{propertyName}}	<h2>Site Visit Booking Confirmed</h2><p>Dear Customer,</p><p>Your site visit for {{propertyName}} has been confirmed for {{visitDate}}.</p><p>Our representative will meet you at the property location. Please arrive on time for the best experience.</p><p>If you need to reschedule, please contact us at least 24 hours in advance.</p>	booking	booking	high	t	t	2025-08-03 19:30:37.601432	2025-08-03 19:30:37.601432
dfcc68a2-563d-4744-af7b-fc0942fd6995	PAYMENT_RECEIVED	Payment Received	Notification when a payment is successfully received	Payment Confirmation	We have received your payment of {{amount}} for {{service}}. Thank you!	OwnItRight: Payment Received - {{amount}}	<h2>Payment Confirmation</h2><p>Dear Customer,</p><p>We have successfully received your payment of {{amount}} for {{service}}.</p><p>Transaction details:</p><ul><li>Amount: {{amount}}</li><li>Service: {{service}}</li><li>Date: {{paymentDate}}</li></ul><p>Thank you for your business!</p>	payment	payment	medium	t	t	2025-08-03 19:30:37.819404	2025-08-03 19:30:37.819404
07dffa5b-fb85-4d0f-8b89-785f5349f8ee	PROPERTY_MATCH	Property Match Found	Notification when a property matches user criteria	New Property Match Found	We found a property that matches your criteria: {{propertyName}} in {{location}}.	OwnItRight: New Property Match - {{propertyName}}	<h2>New Property Match Found!</h2><p>Dear Customer,</p><p>Great news! We found a property that matches your search criteria:</p><p><strong>{{propertyName}}</strong><br>Location: {{location}}<br>Price: {{price}}<br>Type: {{propertyType}}</p><p>View the property details and schedule a visit through your dashboard.</p>	property	property	medium	t	t	2025-08-03 19:30:38.037312	2025-08-03 19:30:38.037312
58c1fc8d-fdda-423f-aeae-ca999dbfd71a	WELCOME_USER	Welcome New User	Welcome message for new users	Welcome to OwnItRight!	Welcome to OwnItRight! We are here to help you find the perfect property with expert guidance.	Welcome to OwnItRight - Your Property Advisory Partner	<h2>Welcome to OwnItRight!</h2><p>Dear {{userName}},</p><p>Thank you for joining OwnItRight, your trusted property advisory platform.</p><p>We are here to help you:</p><ul><li>Find the perfect property</li><li>Get professional property valuations</li><li>Complete legal due diligence</li><li>Access CIVIL+MEP reports</li></ul><p>Start exploring properties and our services through your personalized dashboard.</p>	info	system	medium	t	t	2025-08-03 19:30:38.255309	2025-08-03 19:30:38.255309
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.notifications (id, user_id, user_type, title, message, type, category, priority, action_url, action_text, is_read, is_archived, read_at, email_sent, email_sent_at, related_entity_type, related_entity_id, metadata, expires_at, scheduled_for, created_at, updated_at) FROM stdin;
15827c36-a698-4555-bd90-3d0a93b59a27	test@example.com	user	Welcome to OwnItRight!	Thank you for joining OwnItRight. Explore our comprehensive property advisory services through your dashboard.	info	system	medium	/user-dashboard	Explore Dashboard	f	f	\N	f	\N	\N	\N	{}	\N	\N	2025-08-03 19:30:38.473272	2025-08-03 19:30:38.473272
57c707c3-3a00-45f3-92c4-9efa13516ab0	test@example.com	user	Property Valuation Report Ready	Your property valuation report for the 3 BHK apartment in Koramangala is now ready for download.	report	report	high	/user-dashboard/valuation-reports	Download Report	f	f	\N	f	\N	\N	\N	{}	\N	\N	2025-08-03 19:30:38.693991	2025-08-03 19:30:38.693991
8d579691-fe81-48ba-af31-5ff60b9a5743	test@example.com	user	Site Visit Scheduled	Your site visit for the property in Whitefield has been scheduled for tomorrow at 2:00 PM.	booking	booking	high	/user-dashboard/bookings	View Details	f	f	\N	f	\N	\N	\N	{}	\N	\N	2025-08-03 19:30:38.911696	2025-08-03 19:30:38.911696
e217f3f9-614e-4f0e-9b9c-b3d14b211d01	\N	all	New Feature: Legal Due Diligence Tracker	Track your property legal verification process with our new 12-step legal due diligence tracker.	info	system	medium	/user-dashboard/legal-tracker	Learn More	f	f	\N	f	\N	\N	\N	{}	\N	\N	2025-08-03 19:30:39.130142	2025-08-03 19:30:39.130142
\.


--
-- Data for Name: properties; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.properties (id, name, type, developer, status, area, zone, address, possession_date, rera_number, rera_approved, infrastructure_verdict, zoning_info, tags, images, videos, youtube_video_url, property_score_id, location_score, amenities_score, value_score, overall_score, area_avg_price_min, area_avg_price_max, city_avg_price_min, city_avg_price_max, price_comparison, title_clearance_status, ownership_type, legal_opinion_provided_by, title_flow_summary, encumbrance_status, ec_extract_link, mutation_status, conversion_certificate, rera_registered, rera_id, rera_link, litigation_status, approving_authorities, layout_sanction_copy_link, legal_comments, legal_verdict_badge, has_civil_mep_report, civil_mep_report_price, civil_mep_report_status, has_valuation_report, valuation_report_price, valuation_report_status, created_at, updated_at) FROM stdin;
ce2da9b1-8550-4b0a-96b4-da0c359096c3	Brigade Woods	villa	Brigade Group	pre-launch	Whitefield	east	Whitefield, East Bengaluru, Karnataka	2027-03	PRM/KA/RERA/1251/310/AG/2021-22	t	Excellent infrastructure, IT hub proximity	Premium residential zone	["rera-approved", "premium"]	[]	[]	\N	\N	0	0	0	0.0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N	[]	\N	\N	\N	f	2999.00	draft	f	15000.00	draft	2025-08-03 19:31:47.988886	2025-08-03 19:31:47.988886
f7ec31bd-7b93-4953-8205-b18aac0aaf8f	Godrej Park Retreat	plot	Godrej Properties	active	Sarjapur Road	south	Sarjapur Road, South Bengaluru, Karnataka	immediate	PRM/KA/RERA/1251/311/AG/2020-21	t	Developing area, flood risk present	Residential zone with environmental concerns	["rera-approved", "flood-zone"]	[]	[]	\N	\N	0	0	0	0.0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N	[]	\N	\N	\N	f	2999.00	draft	f	15000.00	draft	2025-08-03 19:31:47.988886	2025-08-03 19:31:47.988886
17783fdf-3bff-4faa-895c-0d703be029b9	Sobha Neopolis	apartment	Sobha Limited	under-construction	Panathur	east	Panathur Road, East Bengaluru, Karnataka	2026-09	PRM/KA/RERA/1251/312/AG/2023-24	t	Excellent IT connectivity, upcoming metro	IT corridor residential zone	["rera-approved", "premium", "it-hub-proximity"]	[]	[]	\N	\N	0	0	0	0.0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N	[]	\N	\N	\N	f	2999.00	draft	f	15000.00	draft	2025-08-03 19:31:47.988886	2025-08-03 19:31:47.988886
6282b431-ee36-4f82-b9f0-1289af40d28a	Ozone Urbana Prime	villa	Ozone Group	completed	Devanahalli	north	Devanahalli, North Bengaluru, Karnataka	immediate	PRM/KA/RERA/1251/313/AG/2021-22	t	Airport proximity, good infrastructure	Premium residential with golf course views	["rera-approved", "premium", "golf-course", "eco-friendly"]	[]	[]	\N	\N	0	0	0	0.0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N	[]	\N	\N	\N	f	2999.00	draft	f	15000.00	draft	2025-08-03 19:31:47.988886	2025-08-03 19:31:47.988886
2a1dabd5-632f-474b-851e-52934c1faa86	Prestige Lakeside Habitat	apartment	Prestige Group	active	Varthur	east	Varthur, East Bengaluru, Karnataka	2025-12	PRM/KA/RERA/1251/309/AG/2020-21	t	Good connectivity, metro planned	Residential zone with mixed development	["rera-approved", "gated-community"]	[]	[]	\N	\N	0	0	0	0.0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N	[]	\N	\N	\N	t	2999.00	draft	f	15000.00	draft	2025-08-03 19:31:47.988886	2025-08-03 19:31:47.988886
\.


--
-- Data for Name: property_configurations; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.property_configurations (id, property_id, configuration, price_per_sqft, built_up_area, plot_size, availability_status, total_units, available_units, price, created_at, updated_at) FROM stdin;
a75c7efc-82de-4905-b8db-e8d0067a5b76	2a1dabd5-632f-474b-851e-52934c1faa86	3BHK	6500.00	1850	\N	available	120	45	12000000	2025-08-03 19:32:48.98687	2025-08-03 19:32:48.98687
f161b58a-3de6-442e-8da6-d05f6e5d9abd	2a1dabd5-632f-474b-851e-52934c1faa86	2BHK	6800.00	1200	\N	available	80	25	8160000	2025-08-03 19:32:48.98687	2025-08-03 19:32:48.98687
a087baac-fd98-47b6-9eb2-68ca745aff96	ce2da9b1-8550-4b0a-96b4-da0c359096c3	4BHK Villa	8500.00	3200	\N	pre-launch	45	45	27200000	2025-08-03 19:32:48.98687	2025-08-03 19:32:48.98687
2b52232a-9bc5-4260-9a3c-c90e98a334e6	f7ec31bd-7b93-4953-8205-b18aac0aaf8f	30x40 Plot	4500.00	1200	1200	available	150	80	5400000	2025-08-03 19:32:48.98687	2025-08-03 19:32:48.98687
2228da40-865f-4395-842a-f9ecfcd8751c	17783fdf-3bff-4faa-895c-0d703be029b9	3BHK	7200.00	1950	\N	available	200	120	14040000	2025-08-03 19:32:48.98687	2025-08-03 19:32:48.98687
c4f92b86-eac5-442b-bacc-5c948cab909b	17783fdf-3bff-4faa-895c-0d703be029b9	2BHK	7500.00	1300	\N	available	150	90	9750000	2025-08-03 19:32:48.98687	2025-08-03 19:32:48.98687
1ccb63ae-3d91-4d72-9924-eec9ce9e9e14	6282b431-ee36-4f82-b9f0-1289af40d28a	4BHK Villa	9200.00	3500	\N	available	25	8	32200000	2025-08-03 19:32:48.98687	2025-08-03 19:32:48.98687
\.


--
-- Data for Name: property_scores; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.property_scores (id, property_id, scoring_version, scored_by, scoring_date, last_updated, transport_connectivity, transport_notes, infrastructure_development, infrastructure_notes, social_infrastructure, social_notes, employment_hubs, employment_notes, basic_amenities, basic_amenities_notes, lifestyle_amenities, lifestyle_amenities_notes, modern_features, modern_features_notes, rera_compliance, rera_compliance_notes, title_clarity, title_clarity_notes, approvals, approvals_notes, price_competitiveness, price_competitiveness_notes, appreciation_potential, appreciation_potential_notes, rental_yield, rental_yield_notes, track_record, track_record_notes, financial_stability, financial_stability_notes, customer_satisfaction, customer_satisfaction_notes, structural_quality, structural_quality_notes, finishing_standards, finishing_standards_notes, maintenance_standards, maintenance_standards_notes, location_score_total, amenities_score_total, legal_score_total, value_score_total, developer_score_total, construction_score_total, overall_score_total, overall_grade, key_strengths, areas_of_concern, recommendation_summary, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: property_valuation_reports; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.property_valuation_reports (id, property_id, report_version, generated_by, report_date, market_analysis, property_assessment, cost_breakdown, financial_analysis, investment_recommendation, risk_assessment, executive_summary, overall_score, key_highlights, report_pdf_url, supporting_documents, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: report_payments; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.report_payments (id, report_id, report_type, property_id, customer_name, customer_email, customer_phone, amount, currency, payment_method, payment_status, stripe_payment_intent_id, stripe_customer_id, pay_later_due_date, pay_later_reminders_sent, access_granted_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: rera_data; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.rera_data (id, rera_id, property_id, project_name, promoter_name, location, district, state, project_type, total_units, project_area, built_up_area, registration_date, approval_date, completion_date, registration_valid_till, project_status, compliance_status, project_cost, amount_collected, percentage_collected, website, contact_phone, contact_email, promoter_address, rera_portal_link, verification_status, last_verified_at, last_sync_at, sync_failure_reason, raw_api_response, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: team_members; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.team_members (id, name, email, phone, role, department, permissions, status, join_date, last_active, profile_image, bio, specializations, performance_score, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.users (id, email, name, role, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: valuation_requests; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.valuation_requests (id, property_type, location, area, age, bedrooms, amenities, additional_info, contact_name, contact_phone, contact_email, status, request_source, estimated_value, value_range, confidence_level, report_generated, report_url, report_notes, assigned_to, processed_at, created_at, updated_at) FROM stdin;
\.


--
-- Name: api_keys_settings api_keys_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.api_keys_settings
    ADD CONSTRAINT api_keys_settings_pkey PRIMARY KEY (id);


--
-- Name: app_settings app_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.app_settings
    ADD CONSTRAINT app_settings_pkey PRIMARY KEY (id);


--
-- Name: blog_posts blog_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.blog_posts
    ADD CONSTRAINT blog_posts_pkey PRIMARY KEY (id);


--
-- Name: blog_posts blog_posts_slug_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.blog_posts
    ADD CONSTRAINT blog_posts_slug_unique UNIQUE (slug);


--
-- Name: bookings bookings_booking_id_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_booking_id_unique UNIQUE (booking_id);


--
-- Name: bookings bookings_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_pkey PRIMARY KEY (id);


--
-- Name: civil_mep_reports civil_mep_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.civil_mep_reports
    ADD CONSTRAINT civil_mep_reports_pkey PRIMARY KEY (id);


--
-- Name: customer_notes customer_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.customer_notes
    ADD CONSTRAINT customer_notes_pkey PRIMARY KEY (id);


--
-- Name: lead_activities lead_activities_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.lead_activities
    ADD CONSTRAINT lead_activities_pkey PRIMARY KEY (id);


--
-- Name: lead_notes lead_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.lead_notes
    ADD CONSTRAINT lead_notes_pkey PRIMARY KEY (id);


--
-- Name: leads leads_lead_id_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_lead_id_unique UNIQUE (lead_id);


--
-- Name: leads leads_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_pkey PRIMARY KEY (id);


--
-- Name: notification_preferences notification_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_pkey PRIMARY KEY (id);


--
-- Name: notification_templates notification_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.notification_templates
    ADD CONSTRAINT notification_templates_pkey PRIMARY KEY (id);


--
-- Name: notification_templates notification_templates_template_key_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.notification_templates
    ADD CONSTRAINT notification_templates_template_key_unique UNIQUE (template_key);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: properties properties_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.properties
    ADD CONSTRAINT properties_pkey PRIMARY KEY (id);


--
-- Name: property_configurations property_configurations_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.property_configurations
    ADD CONSTRAINT property_configurations_pkey PRIMARY KEY (id);


--
-- Name: property_scores property_scores_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.property_scores
    ADD CONSTRAINT property_scores_pkey PRIMARY KEY (id);


--
-- Name: property_valuation_reports property_valuation_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.property_valuation_reports
    ADD CONSTRAINT property_valuation_reports_pkey PRIMARY KEY (id);


--
-- Name: report_payments report_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.report_payments
    ADD CONSTRAINT report_payments_pkey PRIMARY KEY (id);


--
-- Name: rera_data rera_data_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.rera_data
    ADD CONSTRAINT rera_data_pkey PRIMARY KEY (id);


--
-- Name: rera_data rera_data_rera_id_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.rera_data
    ADD CONSTRAINT rera_data_rera_id_unique UNIQUE (rera_id);


--
-- Name: team_members team_members_email_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_email_unique UNIQUE (email);


--
-- Name: team_members team_members_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_pkey PRIMARY KEY (id);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: valuation_requests valuation_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.valuation_requests
    ADD CONSTRAINT valuation_requests_pkey PRIMARY KEY (id);


--
-- Name: bookings bookings_property_id_properties_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_property_id_properties_id_fk FOREIGN KEY (property_id) REFERENCES public.properties(id);


--
-- Name: civil_mep_reports civil_mep_reports_property_id_properties_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.civil_mep_reports
    ADD CONSTRAINT civil_mep_reports_property_id_properties_id_fk FOREIGN KEY (property_id) REFERENCES public.properties(id);


--
-- Name: lead_activities lead_activities_lead_id_leads_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.lead_activities
    ADD CONSTRAINT lead_activities_lead_id_leads_id_fk FOREIGN KEY (lead_id) REFERENCES public.leads(id) ON DELETE CASCADE;


--
-- Name: lead_notes lead_notes_lead_id_leads_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.lead_notes
    ADD CONSTRAINT lead_notes_lead_id_leads_id_fk FOREIGN KEY (lead_id) REFERENCES public.leads(id) ON DELETE CASCADE;


--
-- Name: leads leads_property_id_properties_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_property_id_properties_id_fk FOREIGN KEY (property_id) REFERENCES public.properties(id);


--
-- Name: properties properties_property_score_id_property_scores_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.properties
    ADD CONSTRAINT properties_property_score_id_property_scores_id_fk FOREIGN KEY (property_score_id) REFERENCES public.property_scores(id);


--
-- Name: property_configurations property_configurations_property_id_properties_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.property_configurations
    ADD CONSTRAINT property_configurations_property_id_properties_id_fk FOREIGN KEY (property_id) REFERENCES public.properties(id) ON DELETE CASCADE;


--
-- Name: property_valuation_reports property_valuation_reports_property_id_properties_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.property_valuation_reports
    ADD CONSTRAINT property_valuation_reports_property_id_properties_id_fk FOREIGN KEY (property_id) REFERENCES public.properties(id);


--
-- Name: report_payments report_payments_property_id_properties_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.report_payments
    ADD CONSTRAINT report_payments_property_id_properties_id_fk FOREIGN KEY (property_id) REFERENCES public.properties(id);


--
-- Name: rera_data rera_data_property_id_properties_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.rera_data
    ADD CONSTRAINT rera_data_property_id_properties_id_fk FOREIGN KEY (property_id) REFERENCES public.properties(id);


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO neon_superuser WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON TABLES TO neon_superuser WITH GRANT OPTION;


--
-- PostgreSQL database dump complete
--

