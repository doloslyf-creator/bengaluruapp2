--
-- PostgreSQL database dump
--

-- Dumped from database version 16.9
-- Dumped by pg_dump version 16.9

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: api_keys_settings; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.api_keys_settings (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    razorpay_key_id text,
    razorpay_key_secret text,
    razorpay_webhook_secret text,
    razorpay_test_mode boolean DEFAULT true,
    google_maps_api_key text,
    google_analytics_id text,
    twilio_account_sid text,
    twilio_auth_token text,
    twilio_phone_number text,
    whatsapp_business_api_key text,
    whatsapp_phone_number_id text,
    sendgrid_api_key text,
    sendgrid_from_email text,
    surepass_api_key text,
    signzy_api_key text,
    magicbricks_api_key text,
    acres_99_api_key text,
    last_updated timestamp without time zone DEFAULT now(),
    updated_by text DEFAULT 'admin'::text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.api_keys_settings OWNER TO neondb_owner;

--
-- Name: app_settings; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.app_settings (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    business_name text DEFAULT 'OwnItRight – Curated Property Advisors'::text,
    logo_url text,
    favicon_url text,
    contact_email text DEFAULT 'contact@ownitright.com'::text,
    phone_number text DEFAULT '+91 98765 43210'::text,
    whatsapp_number text DEFAULT '+91 98765 43210'::text,
    office_address text DEFAULT 'Bengaluru, Karnataka, India'::text,
    default_currency character varying DEFAULT 'INR'::character varying,
    currency_symbol text DEFAULT '₹'::text,
    timezone text DEFAULT 'Asia/Kolkata'::text,
    date_format character varying DEFAULT 'DD/MM/YYYY'::character varying,
    maintenance_mode boolean DEFAULT false,
    maintenance_message text DEFAULT 'We are currently performing maintenance. Please check back later.'::text,
    primary_color text DEFAULT '#2563eb'::text,
    secondary_color text DEFAULT '#64748b'::text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.app_settings OWNER TO neondb_owner;

--
-- Name: blog_posts; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.blog_posts (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    title text NOT NULL,
    slug text NOT NULL,
    excerpt text,
    content text NOT NULL,
    meta_title text,
    meta_description text,
    tags json DEFAULT '[]'::json NOT NULL,
    category character varying NOT NULL,
    status character varying DEFAULT 'draft'::character varying NOT NULL,
    published_at timestamp without time zone,
    featured_image text,
    images json DEFAULT '[]'::json NOT NULL,
    author text NOT NULL,
    reading_time integer DEFAULT 5,
    views integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.blog_posts OWNER TO neondb_owner;

--
-- Name: bookings; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.bookings (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    booking_id character varying NOT NULL,
    property_id character varying,
    property_name text NOT NULL,
    booking_type character varying NOT NULL,
    name text NOT NULL,
    phone text NOT NULL,
    email text NOT NULL,
    preferred_date text,
    preferred_time text,
    visit_type character varying,
    number_of_visitors text,
    consultation_type character varying,
    preferred_contact_time text,
    urgency character varying,
    questions text,
    special_requests text,
    status character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.bookings OWNER TO neondb_owner;

--
-- Name: civil_mep_reports; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.civil_mep_reports (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    property_id character varying,
    report_title text NOT NULL,
    engineer_name text NOT NULL,
    engineer_license text NOT NULL,
    inspection_date date NOT NULL,
    report_date date NOT NULL,
    status character varying DEFAULT 'draft'::character varying NOT NULL,
    overall_score real DEFAULT 0,
    site_information json,
    foundation_details json,
    superstructure_details json,
    walls_finishes json,
    roofing_details json,
    doors_windows json,
    flooring_details json,
    staircases_elevators json,
    external_works json,
    mechanical_systems json,
    electrical_systems json,
    plumbing_systems json,
    fire_safety_systems json,
    bms_automation json,
    green_sustainability json,
    documentation json,
    executive_summary text,
    recommendations text,
    conclusions text,
    investment_recommendation character varying DEFAULT 'conditional'::character varying,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.civil_mep_reports OWNER TO neondb_owner;

--
-- Name: customer_notes; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.customer_notes (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    customer_id character varying NOT NULL,
    content text NOT NULL,
    created_by text DEFAULT 'admin'::text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.customer_notes OWNER TO neondb_owner;

--
-- Name: lead_activities; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.lead_activities (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    lead_id character varying NOT NULL,
    activity_type character varying NOT NULL,
    subject text NOT NULL,
    description text,
    outcome character varying,
    next_action text,
    scheduled_at timestamp without time zone,
    completed_at timestamp without time zone,
    performed_by text NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.lead_activities OWNER TO neondb_owner;

--
-- Name: lead_notes; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.lead_notes (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    lead_id character varying NOT NULL,
    note text NOT NULL,
    note_type character varying DEFAULT 'general'::character varying,
    is_private boolean DEFAULT false,
    created_by text NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.lead_notes OWNER TO neondb_owner;

--
-- Name: leads; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.leads (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    lead_id character varying NOT NULL,
    source character varying NOT NULL,
    lead_type character varying DEFAULT 'warm'::character varying NOT NULL,
    priority character varying DEFAULT 'medium'::character varying NOT NULL,
    customer_name text NOT NULL,
    phone text NOT NULL,
    email text NOT NULL,
    property_id character varying,
    property_name text NOT NULL,
    interested_configuration text,
    budget_range text,
    lead_details json DEFAULT '{}'::json NOT NULL,
    lead_score integer DEFAULT 0,
    qualification_notes text,
    status character varying DEFAULT 'new'::character varying NOT NULL,
    assigned_to text,
    last_contact_date timestamp without time zone,
    next_follow_up_date timestamp without time zone,
    communication_preference character varying DEFAULT 'phone'::character varying,
    expected_close_date timestamp without time zone,
    deal_value integer,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.leads OWNER TO neondb_owner;

--
-- Name: notification_preferences; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.notification_preferences (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    user_type character varying DEFAULT 'user'::character varying NOT NULL,
    email_notifications boolean DEFAULT true NOT NULL,
    push_notifications boolean DEFAULT true NOT NULL,
    sms_notifications boolean DEFAULT false NOT NULL,
    property_updates boolean DEFAULT true NOT NULL,
    report_notifications boolean DEFAULT true NOT NULL,
    booking_notifications boolean DEFAULT true NOT NULL,
    payment_notifications boolean DEFAULT true NOT NULL,
    lead_notifications boolean DEFAULT true NOT NULL,
    system_notifications boolean DEFAULT true NOT NULL,
    promotional_notifications boolean DEFAULT false NOT NULL,
    digest_frequency character varying DEFAULT 'immediate'::character varying NOT NULL,
    quiet_hours_start character varying DEFAULT '22:00'::character varying,
    quiet_hours_end character varying DEFAULT '08:00'::character varying,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.notification_preferences OWNER TO neondb_owner;

--
-- Name: notification_templates; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.notification_templates (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    template_key character varying NOT NULL,
    name character varying NOT NULL,
    description text,
    title_template character varying NOT NULL,
    message_template text NOT NULL,
    email_subject_template character varying,
    email_body_template text,
    type character varying DEFAULT 'info'::character varying NOT NULL,
    category character varying DEFAULT 'system'::character varying NOT NULL,
    priority character varying DEFAULT 'medium'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    requires_email boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.notification_templates OWNER TO neondb_owner;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.notifications (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying,
    user_type character varying DEFAULT 'user'::character varying NOT NULL,
    title character varying NOT NULL,
    message text NOT NULL,
    type character varying DEFAULT 'info'::character varying NOT NULL,
    category character varying DEFAULT 'system'::character varying NOT NULL,
    priority character varying DEFAULT 'medium'::character varying NOT NULL,
    action_url character varying,
    action_text character varying,
    is_read boolean DEFAULT false NOT NULL,
    is_archived boolean DEFAULT false NOT NULL,
    read_at timestamp without time zone,
    email_sent boolean DEFAULT false NOT NULL,
    email_sent_at timestamp without time zone,
    related_entity_type character varying,
    related_entity_id character varying,
    metadata json DEFAULT '{}'::json,
    expires_at timestamp without time zone,
    scheduled_for timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.notifications OWNER TO neondb_owner;

--
-- Name: properties; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.properties (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    type character varying NOT NULL,
    developer text NOT NULL,
    status character varying NOT NULL,
    area text NOT NULL,
    zone character varying NOT NULL,
    address text NOT NULL,
    possession_date text,
    rera_number text,
    rera_approved boolean DEFAULT false,
    infrastructure_verdict text,
    zoning_info text,
    tags json DEFAULT '[]'::json NOT NULL,
    images json DEFAULT '[]'::json NOT NULL,
    videos json DEFAULT '[]'::json NOT NULL,
    youtube_video_url text,
    property_score_id character varying,
    location_score integer DEFAULT 0,
    amenities_score integer DEFAULT 0,
    value_score integer DEFAULT 0,
    overall_score numeric(3,1) DEFAULT 0.0,
    area_avg_price_min integer,
    area_avg_price_max integer,
    city_avg_price_min integer,
    city_avg_price_max integer,
    price_comparison text,
    title_clearance_status text,
    ownership_type text,
    legal_opinion_provided_by text,
    title_flow_summary text,
    encumbrance_status text,
    ec_extract_link text,
    mutation_status text,
    conversion_certificate boolean DEFAULT false,
    rera_registered boolean DEFAULT false,
    rera_id text,
    rera_link text,
    litigation_status text,
    approving_authorities json DEFAULT '[]'::json,
    layout_sanction_copy_link text,
    legal_comments text,
    legal_verdict_badge text,
    has_civil_mep_report boolean DEFAULT false,
    civil_mep_report_price numeric(10,2) DEFAULT 2999.00,
    civil_mep_report_status character varying DEFAULT 'draft'::character varying,
    has_valuation_report boolean DEFAULT false,
    valuation_report_price numeric(10,2) DEFAULT 15000.00,
    valuation_report_status character varying DEFAULT 'draft'::character varying,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.properties OWNER TO neondb_owner;

--
-- Name: property_configurations; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.property_configurations (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    property_id character varying NOT NULL,
    configuration text NOT NULL,
    price_per_sqft numeric(10,2) NOT NULL,
    built_up_area integer NOT NULL,
    plot_size integer,
    availability_status character varying NOT NULL,
    total_units integer,
    available_units integer,
    price integer NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.property_configurations OWNER TO neondb_owner;

--
-- Name: property_scores; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.property_scores (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    property_id character varying NOT NULL,
    scoring_version text DEFAULT '1.0'::text,
    scored_by text,
    scoring_date timestamp without time zone DEFAULT now(),
    last_updated timestamp without time zone DEFAULT now(),
    transport_connectivity integer DEFAULT 0,
    transport_notes text,
    infrastructure_development integer DEFAULT 0,
    infrastructure_notes text,
    social_infrastructure integer DEFAULT 0,
    social_notes text,
    employment_hubs integer DEFAULT 0,
    employment_notes text,
    basic_amenities integer DEFAULT 0,
    basic_amenities_notes text,
    lifestyle_amenities integer DEFAULT 0,
    lifestyle_amenities_notes text,
    modern_features integer DEFAULT 0,
    modern_features_notes text,
    rera_compliance integer DEFAULT 0,
    rera_compliance_notes text,
    title_clarity integer DEFAULT 0,
    title_clarity_notes text,
    approvals integer DEFAULT 0,
    approvals_notes text,
    price_competitiveness integer DEFAULT 0,
    price_competitiveness_notes text,
    appreciation_potential integer DEFAULT 0,
    appreciation_potential_notes text,
    rental_yield integer DEFAULT 0,
    rental_yield_notes text,
    track_record integer DEFAULT 0,
    track_record_notes text,
    financial_stability integer DEFAULT 0,
    financial_stability_notes text,
    customer_satisfaction integer DEFAULT 0,
    customer_satisfaction_notes text,
    structural_quality integer DEFAULT 0,
    structural_quality_notes text,
    finishing_standards integer DEFAULT 0,
    finishing_standards_notes text,
    maintenance_standards integer DEFAULT 0,
    maintenance_standards_notes text,
    location_score_total integer DEFAULT 0,
    amenities_score_total integer DEFAULT 0,
    legal_score_total integer DEFAULT 0,
    value_score_total integer DEFAULT 0,
    developer_score_total integer DEFAULT 0,
    construction_score_total integer DEFAULT 0,
    overall_score_total integer DEFAULT 0,
    overall_grade character varying,
    key_strengths json DEFAULT '[]'::json,
    areas_of_concern json DEFAULT '[]'::json,
    recommendation_summary text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.property_scores OWNER TO neondb_owner;

--
-- Name: property_valuation_report_configurations; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.property_valuation_report_configurations (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    report_id character varying NOT NULL,
    configuration_type text NOT NULL,
    configuration_name text,
    is_primary boolean DEFAULT false,
    built_up_area numeric(8,2),
    super_built_up_area numeric(8,2),
    carpet_area numeric(8,2),
    plot_area numeric(8,2),
    balcony_area numeric(8,2),
    uds_share numeric(8,2),
    uds_percentage numeric(5,2),
    land_share_value numeric(12,2),
    basic_price numeric(12,2),
    rate_per_sqft numeric(10,2),
    rate_per_sqft_bua numeric(10,2),
    rate_per_sqft_sba numeric(10,2),
    total_price numeric(12,2),
    amenities_charges numeric(10,2),
    maintenance_charges numeric(10,2),
    parking_charges numeric(10,2),
    floor_rise_charges numeric(10,2),
    number_of_bedrooms integer,
    number_of_bathrooms integer,
    number_of_balconies integer,
    facing text,
    floor_number text,
    total_units integer,
    available_units integer,
    sold_units integer,
    configuration_notes text,
    amenities_included jsonb DEFAULT '[]'::jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.property_valuation_report_configurations OWNER TO neondb_owner;

--
-- Name: property_valuation_report_customers; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.property_valuation_report_customers (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    report_id character varying NOT NULL,
    customer_id character varying NOT NULL,
    assigned_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    assigned_by character varying NOT NULL
);


ALTER TABLE public.property_valuation_report_customers OWNER TO neondb_owner;

--
-- Name: property_valuation_reports; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.property_valuation_reports (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    property_id character varying NOT NULL,
    customer_id character varying,
    report_title text NOT NULL,
    report_status character varying DEFAULT 'draft'::character varying,
    created_by text NOT NULL,
    assigned_to text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    delivered_at timestamp without time zone,
    estimated_market_value numeric(12,2),
    rate_per_sqft numeric(8,2),
    buyer_fit character varying,
    valuation_verdict text,
    appreciation_outlook text,
    risk_score integer DEFAULT 0,
    recommendation text,
    unit_type character varying,
    configuration text,
    uds_area numeric(8,2),
    facing text,
    vastu_compliance boolean DEFAULT false,
    occc_status text,
    possession_status character varying,
    khata_type character varying,
    land_title_status text,
    builder_reputation_score integer DEFAULT 0,
    builder_quoted_price numeric(12,2),
    actual_market_value numeric(12,2),
    price_per_sqft_carpet numeric(8,2),
    price_per_sqft_sba numeric(8,2),
    price_per_sqft_uds numeric(8,2),
    land_share_value numeric(12,2),
    construction_component numeric(12,2),
    guidance_value_zone_rate numeric(8,2),
    pricing_analysis text,
    comparable_sales json,
    benchmarking_sources text,
    volatility_index text,
    days_on_market integer,
    planning_authority character varying,
    zonal_classification character varying,
    land_use_status character varying,
    connectivity_score integer DEFAULT 0,
    water_supply character varying,
    drainage_system character varying,
    social_infra_score integer DEFAULT 0,
    future_dev_impact text,
    rera_registration text,
    khata_verified boolean DEFAULT false,
    sale_deed_title text,
    dc_conversion boolean DEFAULT false,
    plan_approval text,
    occc_received boolean DEFAULT false,
    loan_approval_banks text,
    title_clarity_notes text,
    expected_monthly_rent numeric(8,2),
    gross_rental_yield numeric(5,2),
    tenant_demand character varying,
    exit_liquidity text,
    yield_score numeric(3,1),
    cost_breakdown json,
    total_all_in_price numeric(12,2),
    pros json,
    cons json,
    type_fit text,
    negotiation_advice text,
    risk_summary text,
    appreciation_outlook_5yr text,
    exit_plan text,
    appendices json,
    custom_notes text,
    project_name text,
    tower_unit text,
    rate_per_sqft_sba_uds text,
    undivided_land_share text,
    oc_cc_status text,
    builder_reputation_score_text text,
    total_estimated_value text,
    price_per_sqft_analysis text,
    construction_value text,
    market_premium_discount text,
    average_days_on_market integer,
    connectivity text,
    drainage text,
    social_infrastructure text,
    future_infrastructure json,
    khata_verification text,
    title_clearance text,
    dc_conversion_status text,
    loan_approval json,
    expected_monthly_rent_text text,
    gross_rental_yield_text text,
    yield_score_text text,
    base_unit_cost text,
    amenities_charges text,
    floor_rise_charges text,
    gst_amount text,
    stamp_duty_registration text,
    total_all_in_price_text text,
    khata_transfer_costs text,
    buyer_type_fit text,
    overall_score text
);


ALTER TABLE public.property_valuation_reports OWNER TO neondb_owner;

--
-- Name: report_payments; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.report_payments (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    report_id character varying,
    report_type character varying DEFAULT 'civil-mep'::character varying NOT NULL,
    property_id character varying,
    customer_name text NOT NULL,
    customer_email text NOT NULL,
    customer_phone text,
    amount numeric(10,2) NOT NULL,
    currency text DEFAULT 'INR'::text,
    payment_method character varying NOT NULL,
    payment_status character varying DEFAULT 'pending'::character varying,
    stripe_payment_intent_id text,
    stripe_customer_id text,
    pay_later_due_date timestamp without time zone,
    pay_later_reminders_sent integer DEFAULT 0,
    access_granted_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.report_payments OWNER TO neondb_owner;

--
-- Name: rera_data; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.rera_data (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    rera_id text NOT NULL,
    property_id character varying,
    project_name text NOT NULL,
    promoter_name text NOT NULL,
    location text NOT NULL,
    district text NOT NULL,
    state text DEFAULT 'Karnataka'::text,
    project_type character varying DEFAULT 'residential'::character varying,
    total_units integer,
    project_area text,
    built_up_area text,
    registration_date text,
    approval_date text,
    completion_date text,
    registration_valid_till text,
    project_status character varying DEFAULT 'under-construction'::character varying,
    compliance_status character varying DEFAULT 'active'::character varying,
    project_cost text,
    amount_collected text,
    percentage_collected real,
    website text,
    contact_phone text,
    contact_email text,
    promoter_address text,
    rera_portal_link text,
    verification_status character varying DEFAULT 'pending'::character varying,
    last_verified_at timestamp without time zone,
    last_sync_at timestamp without time zone,
    sync_failure_reason text,
    raw_api_response json,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.rera_data OWNER TO neondb_owner;

--
-- Name: team_members; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.team_members (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    name character varying NOT NULL,
    email character varying NOT NULL,
    phone character varying,
    role character varying DEFAULT 'agent'::character varying NOT NULL,
    department character varying DEFAULT 'sales'::character varying NOT NULL,
    permissions json DEFAULT '[]'::json,
    status character varying DEFAULT 'active'::character varying NOT NULL,
    join_date timestamp without time zone DEFAULT now(),
    last_active timestamp without time zone,
    profile_image character varying,
    bio character varying,
    specializations json DEFAULT '[]'::json,
    performance_score integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.team_members OWNER TO neondb_owner;

--
-- Name: users; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.users (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    email text NOT NULL,
    name text NOT NULL,
    role character varying DEFAULT 'user'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.users OWNER TO neondb_owner;

--
-- Name: valuation_requests; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.valuation_requests (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    property_type text NOT NULL,
    location text NOT NULL,
    area integer NOT NULL,
    age integer NOT NULL,
    bedrooms text NOT NULL,
    amenities json DEFAULT '[]'::json,
    additional_info text,
    contact_name text NOT NULL,
    contact_phone text NOT NULL,
    contact_email text NOT NULL,
    status character varying DEFAULT 'pending'::character varying,
    request_source text DEFAULT 'website'::text,
    estimated_value numeric(12,2),
    value_range json,
    confidence_level character varying,
    report_generated boolean DEFAULT false,
    report_url text,
    report_notes text,
    assigned_to text,
    processed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.valuation_requests OWNER TO neondb_owner;

--
-- Data for Name: api_keys_settings; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.api_keys_settings (id, razorpay_key_id, razorpay_key_secret, razorpay_webhook_secret, razorpay_test_mode, google_maps_api_key, google_analytics_id, twilio_account_sid, twilio_auth_token, twilio_phone_number, whatsapp_business_api_key, whatsapp_phone_number_id, sendgrid_api_key, sendgrid_from_email, surepass_api_key, signzy_api_key, magicbricks_api_key, acres_99_api_key, last_updated, updated_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: app_settings; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.app_settings (id, business_name, logo_url, favicon_url, contact_email, phone_number, whatsapp_number, office_address, default_currency, currency_symbol, timezone, date_format, maintenance_mode, maintenance_message, primary_color, secondary_color, created_at, updated_at) FROM stdin;
8f1643d0-0b9e-4ed5-a9eb-4627bb2067b2	OwnItRight – Curated Property Advisors	\N	\N	contact@ownitright.com	+91 98765 43210	+91 98765 43210	Bengaluru, Karnataka, India	INR	₹	Asia/Kolkata	DD/MM/YYYY	f	We are currently performing maintenance. Please check back later.	#2563eb	#64748b	2025-08-04 13:45:24.781443	2025-08-04 16:41:00.876
\.


--
-- Data for Name: blog_posts; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.blog_posts (id, title, slug, excerpt, content, meta_title, meta_description, tags, category, status, published_at, featured_image, images, author, reading_time, views, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: bookings; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.bookings (id, booking_id, property_id, property_name, booking_type, name, phone, email, preferred_date, preferred_time, visit_type, number_of_visitors, consultation_type, preferred_contact_time, urgency, questions, special_requests, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: civil_mep_reports; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.civil_mep_reports (id, property_id, report_title, engineer_name, engineer_license, inspection_date, report_date, status, overall_score, site_information, foundation_details, superstructure_details, walls_finishes, roofing_details, doors_windows, flooring_details, staircases_elevators, external_works, mechanical_systems, electrical_systems, plumbing_systems, fire_safety_systems, bms_automation, green_sustainability, documentation, executive_summary, recommendations, conclusions, investment_recommendation, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: customer_notes; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.customer_notes (id, customer_id, content, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: lead_activities; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.lead_activities (id, lead_id, activity_type, subject, description, outcome, next_action, scheduled_at, completed_at, performed_by, created_at) FROM stdin;
d447d279-5b26-431e-a61e-fc2fa6bb069b	db701dcc-c00a-4c69-8ddc-eeca503a4a2e	note	Customer created with initial notes	Test customer for valuation report assignment	neutral	\N	\N	\N	admin	2025-08-04 15:14:47.631221
a54cdb6d-5afb-4c83-892b-c5d7173f23c2	2ac793d2-b1ae-4641-99cb-5a363b6221f1	note	Customer created with initial notes	Interested in premium properties	neutral	\N	\N	\N	admin	2025-08-04 15:14:48.551687
b1ba7368-2478-42ae-a933-6027b1698a99	eb9b81c1-7171-48cd-adb3-69c36fc39862	note	Customer created with initial notes	Budget conscious buyer	neutral	\N	\N	\N	admin	2025-08-04 15:14:49.466722
\.


--
-- Data for Name: lead_notes; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.lead_notes (id, lead_id, note, note_type, is_private, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: leads; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.leads (id, lead_id, source, lead_type, priority, customer_name, phone, email, property_id, property_name, interested_configuration, budget_range, lead_details, lead_score, qualification_notes, status, assigned_to, last_contact_date, next_follow_up_date, communication_preference, expected_close_date, deal_value, created_at, updated_at) FROM stdin;
db701dcc-c00a-4c69-8ddc-eeca503a4a2e	LD1754320486559980	property-inquiry	warm	medium	John Smith	+91-9876543210	john.smith@email.com	\N	General Inquiry	\N	\N	{"customerNotes":"Test customer for valuation report assignment"}	40	\N	new	\N	\N	\N	phone	\N	\N	2025-08-04 15:14:47.392121	2025-08-04 15:14:47.392121
2ac793d2-b1ae-4641-99cb-5a363b6221f1	LD1754320488200316	property-inquiry	warm	medium	Priya Sharma	+91-9876543211	priya.sharma@email.com	\N	General Inquiry	\N	\N	{"customerNotes":"Interested in premium properties"}	40	\N	new	\N	\N	\N	phone	\N	\N	2025-08-04 15:14:48.318305	2025-08-04 15:14:48.318305
eb9b81c1-7171-48cd-adb3-69c36fc39862	LD1754320489109193	property-inquiry	warm	medium	Rajesh Kumar	+91-9876543212	rajesh.kumar@email.com	\N	General Inquiry	\N	\N	{"customerNotes":"Budget conscious buyer"}	40	\N	new	\N	\N	\N	phone	\N	\N	2025-08-04 15:14:49.233234	2025-08-04 15:14:49.233234
92992eb2-0849-4b5a-b9ec-1c0a789621a6	LD1754320772557195	property-inquiry	warm	medium	Mohd Zaki	98765678978	zaks.chaudhary@gmail.com	\N	villa in adsf	\N	1Cr_2Cr	{"propertyType":"villa","budgetRange":"1Cr_2Cr","preferredLocation":"adsf","leadNotes":"asdf"}	50	\N	new	\N	\N	\N	phone	\N	\N	2025-08-04 15:19:35.734489	2025-08-04 15:19:35.734489
\.


--
-- Data for Name: notification_preferences; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.notification_preferences (id, user_id, user_type, email_notifications, push_notifications, sms_notifications, property_updates, report_notifications, booking_notifications, payment_notifications, lead_notifications, system_notifications, promotional_notifications, digest_frequency, quiet_hours_start, quiet_hours_end, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notification_templates; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.notification_templates (id, template_key, name, description, title_template, message_template, email_subject_template, email_body_template, type, category, priority, is_active, requires_email, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.notifications (id, user_id, user_type, title, message, type, category, priority, action_url, action_text, is_read, is_archived, read_at, email_sent, email_sent_at, related_entity_type, related_entity_id, metadata, expires_at, scheduled_for, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: properties; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.properties (id, name, type, developer, status, area, zone, address, possession_date, rera_number, rera_approved, infrastructure_verdict, zoning_info, tags, images, videos, youtube_video_url, property_score_id, location_score, amenities_score, value_score, overall_score, area_avg_price_min, area_avg_price_max, city_avg_price_min, city_avg_price_max, price_comparison, title_clearance_status, ownership_type, legal_opinion_provided_by, title_flow_summary, encumbrance_status, ec_extract_link, mutation_status, conversion_certificate, rera_registered, rera_id, rera_link, litigation_status, approving_authorities, layout_sanction_copy_link, legal_comments, legal_verdict_badge, has_civil_mep_report, civil_mep_report_price, civil_mep_report_status, has_valuation_report, valuation_report_price, valuation_report_status, created_at, updated_at) FROM stdin;
62f922ac-90f2-4db6-aa5b-88109938729f	Prestige Lake Ridge	apartment	Prestige Group	active	Whitefield	east	Whitefield Main Road, Bengaluru	\N	\N	f	\N	\N	[]	[]	[]	\N	\N	0	0	0	0.0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N	[]	\N	\N	\N	f	2999.00	draft	f	15000.00	draft	2025-08-04 13:53:36.103326	2025-08-04 13:53:36.103326
\.


--
-- Data for Name: property_configurations; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.property_configurations (id, property_id, configuration, price_per_sqft, built_up_area, plot_size, availability_status, total_units, available_units, price, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: property_scores; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.property_scores (id, property_id, scoring_version, scored_by, scoring_date, last_updated, transport_connectivity, transport_notes, infrastructure_development, infrastructure_notes, social_infrastructure, social_notes, employment_hubs, employment_notes, basic_amenities, basic_amenities_notes, lifestyle_amenities, lifestyle_amenities_notes, modern_features, modern_features_notes, rera_compliance, rera_compliance_notes, title_clarity, title_clarity_notes, approvals, approvals_notes, price_competitiveness, price_competitiveness_notes, appreciation_potential, appreciation_potential_notes, rental_yield, rental_yield_notes, track_record, track_record_notes, financial_stability, financial_stability_notes, customer_satisfaction, customer_satisfaction_notes, structural_quality, structural_quality_notes, finishing_standards, finishing_standards_notes, maintenance_standards, maintenance_standards_notes, location_score_total, amenities_score_total, legal_score_total, value_score_total, developer_score_total, construction_score_total, overall_score_total, overall_grade, key_strengths, areas_of_concern, recommendation_summary, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: property_valuation_report_configurations; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.property_valuation_report_configurations (id, report_id, configuration_type, configuration_name, is_primary, built_up_area, super_built_up_area, carpet_area, plot_area, balcony_area, uds_share, uds_percentage, land_share_value, basic_price, rate_per_sqft, rate_per_sqft_bua, rate_per_sqft_sba, total_price, amenities_charges, maintenance_charges, parking_charges, floor_rise_charges, number_of_bedrooms, number_of_bathrooms, number_of_balconies, facing, floor_number, total_units, available_units, sold_units, configuration_notes, amenities_included, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: property_valuation_report_customers; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.property_valuation_report_customers (id, report_id, customer_id, assigned_at, assigned_by) FROM stdin;
44c144d6-024c-4753-80ba-e0ce2e0ab785	97e50960-448a-470b-82a9-3f1b56af19d7	john.smith@email.com	2025-08-04 15:15:02.356064	admin
bc0df0cd-e83f-452a-a254-9378c1449a32	97e50960-448a-470b-82a9-3f1b56af19d7	priya.sharma@email.com	2025-08-04 15:15:02.597783	admin
a8239fb5-ddec-47d4-953d-1f822711d263	97e50960-448a-470b-82a9-3f1b56af19d7	rajesh.kumar@email.com	2025-08-04 15:15:02.830865	admin
9422bdd9-f765-4dcf-8fca-788324619a3c	97e50960-448a-470b-82a9-3f1b56af19d7	zaks.chaudhary@gmail.com	2025-08-04 15:24:53.093426	admin
\.


--
-- Data for Name: property_valuation_reports; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.property_valuation_reports (id, property_id, customer_id, report_title, report_status, created_by, assigned_to, created_at, updated_at, delivered_at, estimated_market_value, rate_per_sqft, buyer_fit, valuation_verdict, appreciation_outlook, risk_score, recommendation, unit_type, configuration, uds_area, facing, vastu_compliance, occc_status, possession_status, khata_type, land_title_status, builder_reputation_score, builder_quoted_price, actual_market_value, price_per_sqft_carpet, price_per_sqft_sba, price_per_sqft_uds, land_share_value, construction_component, guidance_value_zone_rate, pricing_analysis, comparable_sales, benchmarking_sources, volatility_index, days_on_market, planning_authority, zonal_classification, land_use_status, connectivity_score, water_supply, drainage_system, social_infra_score, future_dev_impact, rera_registration, khata_verified, sale_deed_title, dc_conversion, plan_approval, occc_received, loan_approval_banks, title_clarity_notes, expected_monthly_rent, gross_rental_yield, tenant_demand, exit_liquidity, yield_score, cost_breakdown, total_all_in_price, pros, cons, type_fit, negotiation_advice, risk_summary, appreciation_outlook_5yr, exit_plan, appendices, custom_notes, project_name, tower_unit, rate_per_sqft_sba_uds, undivided_land_share, oc_cc_status, builder_reputation_score_text, total_estimated_value, price_per_sqft_analysis, construction_value, market_premium_discount, average_days_on_market, connectivity, drainage, social_infrastructure, future_infrastructure, khata_verification, title_clearance, dc_conversion_status, loan_approval, expected_monthly_rent_text, gross_rental_yield_text, yield_score_text, base_unit_cost, amenities_charges, floor_rise_charges, gst_amount, stamp_duty_registration, total_all_in_price_text, khata_transfer_costs, buyer_type_fit, overall_score) FROM stdin;
97e50960-448a-470b-82a9-3f1b56af19d7	sample-property-123	sample-customer-456	Property Valuation Report - Assetz Marq 3.0	draft	admin-user	\N	2025-08-04 13:51:08.436054	2025-08-04 13:51:08.436054	\N	22000000.00	10200.00	both	\N	\N	0	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	0	\N	\N	f	\N	f	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: report_payments; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.report_payments (id, report_id, report_type, property_id, customer_name, customer_email, customer_phone, amount, currency, payment_method, payment_status, stripe_payment_intent_id, stripe_customer_id, pay_later_due_date, pay_later_reminders_sent, access_granted_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: rera_data; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.rera_data (id, rera_id, property_id, project_name, promoter_name, location, district, state, project_type, total_units, project_area, built_up_area, registration_date, approval_date, completion_date, registration_valid_till, project_status, compliance_status, project_cost, amount_collected, percentage_collected, website, contact_phone, contact_email, promoter_address, rera_portal_link, verification_status, last_verified_at, last_sync_at, sync_failure_reason, raw_api_response, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: team_members; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.team_members (id, name, email, phone, role, department, permissions, status, join_date, last_active, profile_image, bio, specializations, performance_score, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.users (id, email, name, role, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: valuation_requests; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.valuation_requests (id, property_type, location, area, age, bedrooms, amenities, additional_info, contact_name, contact_phone, contact_email, status, request_source, estimated_value, value_range, confidence_level, report_generated, report_url, report_notes, assigned_to, processed_at, created_at, updated_at) FROM stdin;
\.


--
-- Name: api_keys_settings api_keys_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.api_keys_settings
    ADD CONSTRAINT api_keys_settings_pkey PRIMARY KEY (id);


--
-- Name: app_settings app_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.app_settings
    ADD CONSTRAINT app_settings_pkey PRIMARY KEY (id);


--
-- Name: blog_posts blog_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.blog_posts
    ADD CONSTRAINT blog_posts_pkey PRIMARY KEY (id);


--
-- Name: blog_posts blog_posts_slug_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.blog_posts
    ADD CONSTRAINT blog_posts_slug_unique UNIQUE (slug);


--
-- Name: bookings bookings_booking_id_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_booking_id_unique UNIQUE (booking_id);


--
-- Name: bookings bookings_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_pkey PRIMARY KEY (id);


--
-- Name: civil_mep_reports civil_mep_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.civil_mep_reports
    ADD CONSTRAINT civil_mep_reports_pkey PRIMARY KEY (id);


--
-- Name: customer_notes customer_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.customer_notes
    ADD CONSTRAINT customer_notes_pkey PRIMARY KEY (id);


--
-- Name: lead_activities lead_activities_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.lead_activities
    ADD CONSTRAINT lead_activities_pkey PRIMARY KEY (id);


--
-- Name: lead_notes lead_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.lead_notes
    ADD CONSTRAINT lead_notes_pkey PRIMARY KEY (id);


--
-- Name: leads leads_lead_id_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_lead_id_unique UNIQUE (lead_id);


--
-- Name: leads leads_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_pkey PRIMARY KEY (id);


--
-- Name: notification_preferences notification_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_pkey PRIMARY KEY (id);


--
-- Name: notification_templates notification_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.notification_templates
    ADD CONSTRAINT notification_templates_pkey PRIMARY KEY (id);


--
-- Name: notification_templates notification_templates_template_key_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.notification_templates
    ADD CONSTRAINT notification_templates_template_key_unique UNIQUE (template_key);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: properties properties_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.properties
    ADD CONSTRAINT properties_pkey PRIMARY KEY (id);


--
-- Name: property_configurations property_configurations_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.property_configurations
    ADD CONSTRAINT property_configurations_pkey PRIMARY KEY (id);


--
-- Name: property_scores property_scores_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.property_scores
    ADD CONSTRAINT property_scores_pkey PRIMARY KEY (id);


--
-- Name: property_valuation_report_configurations property_valuation_report_configurations_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.property_valuation_report_configurations
    ADD CONSTRAINT property_valuation_report_configurations_pkey PRIMARY KEY (id);


--
-- Name: property_valuation_report_customers property_valuation_report_customers_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.property_valuation_report_customers
    ADD CONSTRAINT property_valuation_report_customers_pkey PRIMARY KEY (id);


--
-- Name: property_valuation_report_customers property_valuation_report_customers_report_id_customer_id_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.property_valuation_report_customers
    ADD CONSTRAINT property_valuation_report_customers_report_id_customer_id_key UNIQUE (report_id, customer_id);


--
-- Name: property_valuation_reports property_valuation_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.property_valuation_reports
    ADD CONSTRAINT property_valuation_reports_pkey PRIMARY KEY (id);


--
-- Name: report_payments report_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.report_payments
    ADD CONSTRAINT report_payments_pkey PRIMARY KEY (id);


--
-- Name: rera_data rera_data_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.rera_data
    ADD CONSTRAINT rera_data_pkey PRIMARY KEY (id);


--
-- Name: rera_data rera_data_rera_id_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.rera_data
    ADD CONSTRAINT rera_data_rera_id_unique UNIQUE (rera_id);


--
-- Name: team_members team_members_email_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_email_unique UNIQUE (email);


--
-- Name: team_members team_members_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_pkey PRIMARY KEY (id);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: valuation_requests valuation_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.valuation_requests
    ADD CONSTRAINT valuation_requests_pkey PRIMARY KEY (id);


--
-- Name: idx_report_config; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_report_config ON public.property_valuation_report_configurations USING btree (report_id);


--
-- Name: bookings bookings_property_id_properties_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_property_id_properties_id_fk FOREIGN KEY (property_id) REFERENCES public.properties(id);


--
-- Name: civil_mep_reports civil_mep_reports_property_id_properties_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.civil_mep_reports
    ADD CONSTRAINT civil_mep_reports_property_id_properties_id_fk FOREIGN KEY (property_id) REFERENCES public.properties(id);


--
-- Name: lead_activities lead_activities_lead_id_leads_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.lead_activities
    ADD CONSTRAINT lead_activities_lead_id_leads_id_fk FOREIGN KEY (lead_id) REFERENCES public.leads(id) ON DELETE CASCADE;


--
-- Name: lead_notes lead_notes_lead_id_leads_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.lead_notes
    ADD CONSTRAINT lead_notes_lead_id_leads_id_fk FOREIGN KEY (lead_id) REFERENCES public.leads(id) ON DELETE CASCADE;


--
-- Name: leads leads_property_id_properties_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_property_id_properties_id_fk FOREIGN KEY (property_id) REFERENCES public.properties(id);


--
-- Name: properties properties_property_score_id_property_scores_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.properties
    ADD CONSTRAINT properties_property_score_id_property_scores_id_fk FOREIGN KEY (property_score_id) REFERENCES public.property_scores(id);


--
-- Name: property_configurations property_configurations_property_id_properties_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.property_configurations
    ADD CONSTRAINT property_configurations_property_id_properties_id_fk FOREIGN KEY (property_id) REFERENCES public.properties(id) ON DELETE CASCADE;


--
-- Name: property_valuation_report_configurations property_valuation_report_configurations_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.property_valuation_report_configurations
    ADD CONSTRAINT property_valuation_report_configurations_report_id_fkey FOREIGN KEY (report_id) REFERENCES public.property_valuation_reports(id) ON DELETE CASCADE;


--
-- Name: property_valuation_report_customers property_valuation_report_customers_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.property_valuation_report_customers
    ADD CONSTRAINT property_valuation_report_customers_report_id_fkey FOREIGN KEY (report_id) REFERENCES public.property_valuation_reports(id) ON DELETE CASCADE;


--
-- Name: report_payments report_payments_property_id_properties_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.report_payments
    ADD CONSTRAINT report_payments_property_id_properties_id_fk FOREIGN KEY (property_id) REFERENCES public.properties(id);


--
-- Name: rera_data rera_data_property_id_properties_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.rera_data
    ADD CONSTRAINT rera_data_property_id_properties_id_fk FOREIGN KEY (property_id) REFERENCES public.properties(id);


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO neon_superuser WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON TABLES TO neon_superuser WITH GRANT OPTION;


--
-- PostgreSQL database dump complete
--

